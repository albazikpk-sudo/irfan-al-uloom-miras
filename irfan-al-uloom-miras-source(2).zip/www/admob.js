import { Capacitor } from '@capacitor/core';
import { AdMob, AdmobConsentStatus, BannerAdSize, BannerAdPosition } from '@capacitor-community/admob';

// Google-provided Android test banner. Keep this during testing.
const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/9214589741';
let bannerVisible = false;
let starting = false;

function logStatus(stage, detail = '') {
  const info = { stage, detail, time: new Date().toISOString() };
  window.__IRFAN_ADMOB_STATUS__ = info;
  console.info('[Irfan AdMob]', info);
}

async function showTestBanner() {
  await AdMob.showBanner({
    adId: TEST_BANNER_ID,
    adSize: BannerAdSize.ADAPTIVE_BANNER,
    position: BannerAdPosition.BOTTOM_CENTER,
    margin: 0,
    isTesting: true
  });
  bannerVisible = true;
  logStatus('banner-requested', 'Google test banner request sent');
}

async function startTestBanner() {
  if (!Capacitor.isNativePlatform()) {
    logStatus('skipped', 'Not running inside a native Capacitor app');
    return;
  }
  if (starting || bannerVisible) return;
  starting = true;
  try {
    logStatus('consent-request-started');
    let consent = await AdMob.requestConsentInfo();
    logStatus('consent-info-received', JSON.stringify({
      status: consent.status,
      isConsentFormAvailable: consent.isConsentFormAvailable,
      canRequestAds: consent.canRequestAds
    }));

    if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
      logStatus('consent-form-shown');
      consent = await AdMob.showConsentForm();
      logStatus('consent-form-completed', JSON.stringify({
        status: consent.status,
        canRequestAds: consent.canRequestAds
      }));
    }

    if (!consent.canRequestAds) {
      logStatus('blocked-by-consent', 'Consent SDK reports canRequestAds=false; no ad request made');
      return;
    }

    logStatus('sdk-initialize-started');
    await AdMob.initialize();
    logStatus('sdk-initialized');
    await showTestBanner();
  } catch (error) {
    const detail = error instanceof Error ? `${error.name}: ${error.message}` : String(error);
    logStatus('failed', detail);
    console.error('[Irfan AdMob] Banner setup failed. Calculator remains available.', error);
  } finally {
    starting = false;
  }
}

// Start after the WebView has completed loading. A short delay gives the native
// Capacitor activity time to attach its content view before SDK initialization.
window.addEventListener('load', () => {
  window.setTimeout(startTestBanner, 1200);
}, { once: true });

// Keep native banner ads out of printed and saved-PDF output.
window.addEventListener('beforeprint', () => {
  if (Capacitor.isNativePlatform() && bannerVisible) {
    AdMob.hideBanner().catch(error => logStatus('hide-before-print-failed', String(error)));
  }
});
window.addEventListener('afterprint', () => {
  if (Capacitor.isNativePlatform() && bannerVisible) {
    showTestBanner().catch(error => logStatus('restore-after-print-failed', String(error)));
  }
});
