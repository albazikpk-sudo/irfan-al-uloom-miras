import { Capacitor } from '@capacitor/core';
import { AdMob, AdmobConsentStatus, BannerAdSize, BannerAdPosition } from '@capacitor-community/admob';

const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/9214589741';
// Production Banner Ad Unit ID (enable only after successful test build):
// ca-app-pub-1134522787126944/5939274618

async function startTestBanner() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    let consent = await AdMob.requestConsentInfo();
    if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
      consent = await AdMob.showConsentForm();
    }
    if (!consent.canRequestAds) return;
    await AdMob.initialize();
    await AdMob.showBanner({
      adId: TEST_BANNER_ID,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: true
    });
  } catch (error) {
    console.warn('AdMob banner was not displayed:', error);
    // AdMob failure must never prevent the inheritance calculator from working.
  }
}

window.addEventListener('load', () => {
  // Wait briefly for the Capacitor native view to be ready.
  setTimeout(startTestBanner, 800);
}, { once: true });
