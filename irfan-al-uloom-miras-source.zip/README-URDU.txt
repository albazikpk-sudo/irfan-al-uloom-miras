عرفان العلوم - میراث کیلکولیٹر (Android / Capacitor source)

یہ پروجیکٹ موجودہ miras-android-pwa.zip سے تیار کیا گیا ہے۔ اسے دوبارہ صفر سے نہیں بنایا گیا۔

اہم:
- Android package ID: com.irfanululoom.mirascalculator
- App name: عرفان العلوم میراث کیلکولیٹر
- بنیادی HTML/JS اور آئیکنز www/ میں ہیں۔
- Capacitor مقامی ویب فائلیں Android ایپ کے اندر bundle کرے گا؛ اس لیے بنیادی حساب کے لیے مستقل ویب ہوسٹنگ درکار نہیں ہوگی۔
- Nastaliq فونٹ اگر دستیاب/انٹرنیٹ پر ہو تو استعمال ہوگا؛ آف لائن fallback کے لیے Noto Naskh Arabic فونٹ ساتھ شامل ہے۔

Android project بنانے کے لیے Node.js اور Android Studio/JDK درکار ہیں:
  npm install
  npx cap add android
  npx cap sync android
  npx cap open android

اس کے بعد Android Studio میں Build > Generate Signed Bundle / APK سے AAB بنائیں۔

یہ source bundle ابھی خود دستخط شدہ APK/AAB نہیں ہے۔ Play Store پر اپلوڈ سے پہلے Android build، فون پر مکمل ٹیسٹ، privacy/data safety review اور signing لازمی ہیں۔

Play Store کے لیے package ID مستقل رکھیں؛ اشاعت کے بعد اسے تبدیل نہیں کیا جا سکتا۔ زکوٰۃ ایپ کا package ID الگ ہے، اس لیے میراث ایپ کے لیے الگ ID رکھی گئی ہے۔
