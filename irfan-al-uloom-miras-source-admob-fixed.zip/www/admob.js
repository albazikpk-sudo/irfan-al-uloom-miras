import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdSize,
  BannerAdPosition,
  BannerAdPluginEvents
} from '@capacitor-community/admob';

// Google's official Android banner demo unit. Never use a live unit for testing.
const TEST_BANNER_ID = 'ca-app-pub-3940256099942544/6300978111';
let starting = false;
let initialized = false;
let bannerRequested = false;
let listenersRegistered = false;
let bannerLoaded = false;

function showDiagnostic(stage, detail = '') {
  const record = { stage, detail, time: new Date().toISOString() };
  window.__IRFAN_ADMOB_STATUS__ = record;
  console.info('[Irfan AdMob]', record);
  const panel = document.getElementById('admob-status');
  if (!panel) return;
  if (stage === 'banner-loaded') {
    panel.hidden = true;
    panel.textContent = '';
    return;
  }
  if (stage === 'skipped-web') return;
  panel.hidden = false;
  const messages = {
    'blocked-by-consent': 'اشتہار فی الحال نہیں دکھایا جا سکتا: رازداری کی اجازت دستیاب نہیں۔',
    'consent-error': 'AdMob کی اجازت حاصل کرنے میں مسئلہ پیش آیا۔',
    'sdk-error': 'Google اشتہاری سروس شروع نہیں ہوسکی۔',
    'banner-error': 'اشتہار لوڈ نہیں ہوا۔ انٹرنیٹ یا AdMob کی ترتیب چیک کریں۔',
    'banner-requested': 'ٹیسٹ اشتہار کی درخواست بھیج دی گئی ہے۔',
    'sdk-initialized': 'AdMob سروس شروع ہوگئی؛ اشتہار لوڈ ہونے کا انتظار ہے۔'
  };
  panel.textContent = `${messages[stage] || 'AdMob کی تشخیصی اطلاع'} ${detail ? '(' + detail + ')' : ''}`;
}

async function registerBannerListeners() {
  if (listenersRegistered) return;
  listenersRegistered = true;
  await AdMob.addListener(BannerAdPluginEvents.Loaded, () => {
    bannerLoaded = true;
    showDiagnostic('banner-loaded');
  });
  await AdMob.addListener(BannerAdPluginEvents.FailedToLoad, (error) => {
    bannerLoaded = false;
    showDiagnostic('banner-error', JSON.stringify(error));
  });
  await AdMob.addListener(BannerAdPluginEvents.SizeChanged, (size) => {
    console.info('[Irfan AdMob] Banner size changed', size);
  });
}

async function startTestBanner() {
  if (!Capacitor.isNativePlatform()) {
    showDiagnostic('skipped-web');
    return;
  }
  if (starting || bannerRequested) return;
  starting = true;
  try {
    showDiagnostic('consent-request-started');
    let consent;
    try {
      consent = await AdMob.requestConsentInfo();
    } catch (error) {
      showDiagnostic('consent-error', error instanceof Error ? error.message : String(error));
      return;
    }

    if (consent.isConsentFormAvailable && consent.status === AdmobConsentStatus.REQUIRED) {
      consent = await AdMob.showConsentForm();
    }
    console.info('[Irfan AdMob] Consent result', {
      status: consent.status,
      isConsentFormAvailable: consent.isConsentFormAvailable,
      canRequestAds: consent.canRequestAds
    });

    // UMP defines NOT_REQUIRED and OBTAINED as consent states in which ads
    // may be requested after requestConsentInfo() has completed. Some plugin
    // bridge responses may not reliably expose canRequestAds, so honor these
    // explicit UMP states as well; never override REQUIRED or UNKNOWN.
    const consentAllowsAds = consent.canRequestAds === true ||
      consent.status === AdmobConsentStatus.NOT_REQUIRED ||
      consent.status === AdmobConsentStatus.OBTAINED;

    if (!consentAllowsAds) {
      showDiagnostic('blocked-by-consent', `status=${consent.status}; canRequestAds=${consent.canRequestAds}`);
      return;
    }

    await registerBannerListeners();
    if (!initialized) {
      try {
        await AdMob.initialize();
        initialized = true;
      } catch (error) {
        showDiagnostic('sdk-error', error instanceof Error ? error.message : String(error));
        return;
      }
    }
    showDiagnostic('sdk-initialized');
    await AdMob.showBanner({
      adId: TEST_BANNER_ID,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: true
    });
    bannerRequested = true;
    showDiagnostic('banner-requested');
  } catch (error) {
    showDiagnostic('banner-error', error instanceof Error ? error.message : String(error));
    console.error('[Irfan AdMob] Setup failed; calculator remains usable.', error);
  } finally {
    starting = false;
  }
}

// Capacitor's native WebView must be ready before initializing the SDK.
window.addEventListener('load', () => {
  window.setTimeout(() => { startTestBanner(); }, 1500);
}, { once: true });

// Keep the native banner out of printed/PDF output.
window.addEventListener('beforeprint', () => {
  if (Capacitor.isNativePlatform() && bannerRequested) {
    AdMob.hideBanner().catch(error => console.warn('[Irfan AdMob] hideBanner failed', error));
  }
});
window.addEventListener('afterprint', () => {
  if (Capacitor.isNativePlatform() && bannerRequested) {
    AdMob.showBanner({
      adId: TEST_BANNER_ID,
      adSize: BannerAdSize.ADAPTIVE_BANNER,
      position: BannerAdPosition.BOTTOM_CENTER,
      margin: 0,
      isTesting: true
    }).catch(error => console.warn('[Irfan AdMob] banner restore failed', error));
  }
});
