/* مناسخہ باب — الگ ماڈیول۔
   یہ فائل index.html کے موجودہ حسابی انجن (calc, G, N, MX, gcd, Fr) کو استعمال کرتی ہے
   اور اسے تبدیل نہیں کرتی۔ تمام حساب BigInt سے ہوتا ہے۔ */
(function () {
  'use strict';

  /* ---------- حسابی حصہ (DOM سے آزاد) ---------- */
  function compute(levels) {
    var steps = [], P = new Map(), J = 0n;
    function snap() {
      var a = [];
      P.forEach(function (p) { if (p.alive && p.units > 0n) a.push({ id: p.id, label: dn(p), units: p.units }); });
      return a;
    }
    function dn(p) { return p.label + (p.lv > 1 ? ' [م' + p.lv + ']' : '') + (p.parts.length > 1 ? ' (مشترک)' : ''); }
    function fail(msg, i) { return { err: msg, steps: steps, P: P, J: J, at: i }; }

    for (var i = 0; i < levels.length; i++) {
      var L = levels[i], c = L.c || {};
      if (!Object.keys(MX).some(function (k) { return c[k] > 0; })) return fail('مسئلہ ' + (i + 1) + ': کم از کم ایک وارث منتخب کریں۔', i);
      if (c.H && c.W) return fail('مسئلہ ' + (i + 1) + ': شوہر اور بیویاں ایک ساتھ منتخب نہیں ہو سکتے۔', i);
      var dead = null, s = 0n;
      if (i > 0) {
        dead = P.get(L.dead);
        if (!dead || !dead.alive) return fail('مسئلہ ' + (i + 1) + ': فوت ہونے والا وارث منتخب کریں۔', i);
        s = dead.units;
      }
      var r = calc(c, '');
      if (r.err) return fail('مسئلہ ' + (i + 1) + ': ' + r.err, i);

      var g = null, f1 = 1n, f2 = 1n, kind = '';
      if (i > 0) {
        g = gcd(s, r.corr);
        f1 = r.corr / g;
        f2 = s / g;
        kind = (s % r.corr === 0n) ? 'انقسام' : (g > 1n ? 'توافق' : 'تباین');
        P.forEach(function (p) { if (p.alive) p.units *= f1; });
        dead.alive = false;
      }
      var deadLabel = dead ? dn(dead) : null;
      G.forEach(function (grp) {
        grp[1].forEach(function (h) {
          var k = h[0], n = h[1], t = r.T[k], cnt = r.e[k];
          if (!cnt || !t || t.f.n === 0n) return;
          for (var j = 1; j <= cnt; j++) {
            var id = 'L' + i + '-' + k + '-' + j;
            var label = cnt > 1 ? n + ' ' + j : n;
            var u = t.h * f2;
            var tgt = (i > 0 && L.link) ? L.link[id] : null;
            var tp = tgt ? P.get(tgt) : null;
            if (tp && tp.alive) {
              tp.units += u;
              tp.parts.push({ lv: i + 1, u: u, of: deadLabel });
            } else {
              P.set(id, { id: id, label: label, lv: i + 1, units: u, alive: true, parts: [{ lv: i + 1, u: u, of: deadLabel }] });
            }
          }
        });
      });
      J = (i === 0) ? r.corr : J * f1;
      var sum = 0n;
      P.forEach(function (p) { if (p.alive) sum += p.units; });
      steps.push({
        lv: i + 1, r: r, s: s, g: g, f1: f1, f2: f2, kind: kind, J: J,
        dead: deadLabel, blocked: r.B, ok: sum === J, aliveAfter: snap()
      });
    }
    return { err: null, steps: steps, P: P, J: J, dn: dn };
  }

  function money(v) { return (Number(v) / 100).toLocaleString('en-US', { minimumFractionDigits: 2 }); }

  function distribute(res, est) {
    var Pn = BigInt(Math.round(est * 100)), J = res.J, rows = [], q = {}, rm = [];
    res.P.forEach(function (p) {
      if (!p.alive || p.units <= 0n) return;
      rows.push(p);
      var x = Pn * p.units;
      q[p.id] = x / J;
      rm.push([p.id, x % J]);
    });
    var left = Pn;
    rows.forEach(function (p) { left -= q[p.id]; });
    rm.sort(function (a, b) { return a[1] < b[1] ? 1 : a[1] > b[1] ? -1 : 0; });
    for (var i = 0; i < Number(left); i++) q[rm[i][0]] += 1n;
    return { rows: rows, q: q, left: left, P: Pn };
  }

  function pct(units, J) { return (Number(units * 1000000n / J) / 10000).toFixed(2) + '%'; }

  function relation(p) {
    return p.parts.map(function (x) { return x.of ? 'مرحوم ' + x.of : 'میت'; }).join(' + ');
  }

  /* عام استعمال/ٹیسٹ کے لیے */
  var root = (typeof globalThis !== 'undefined') ? globalThis : window;
  root.MNCORE = { compute: compute, distribute: distribute, pct: pct, money: money };

  /* ---------- یوزر انٹرفیس ---------- */
  if (typeof document === 'undefined' || !document.getElementById('t1')) return;

  var levels = [{ dead: null, c: {}, link: {} }];
  var res = null, show = false, out = '', lastTxt = '';

  function esc(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

  function stepper(i, k) {
    var v = levels[i].c[k] || 0;
    if (MX[k] === 1) {
      return '<button class="' + (v ? 'on' : '') + '" onclick="MNUI.tg(' + i + ",'" + k + "')\">" + (v ? 'موجود' : 'نہیں') + '</button>';
    }
    return '<span class="st"><button onclick="MNUI.ch(' + i + ",'" + k + "',1)\">+</button><b>" + v +
      '</b><button onclick="MNUI.ch(' + i + ",'" + k + "',-1)\">−</button></span>";
  }

  function headsOf(i) {
    var a = [];
    G.forEach(function (grp) {
      grp[1].forEach(function (h) {
        var cnt = levels[i].c[h[0]] || 0;
        for (var j = 1; j <= cnt; j++) a.push({ id: 'L' + i + '-' + h[0] + '-' + j, name: cnt > 1 ? h[1] + ' ' + j : h[1] });
      });
    });
    return a;
  }

  function draw() {
    res = compute(levels);
    var h = '';
    levels.forEach(function (L, i) {
      h += '<div class="card np"><h2>' + (i === 0 ? 'مسئلہ 1: میت کے ورثاء' : 'مسئلہ ' + (i + 1) + ': وارث کی وفات اور اس کے ورثاء') + '</h2>';
      if (i > 0) {
        var prev = res.steps[i - 1], opts = prev ? prev.aliveAfter : [];
        h += '<div class="row"><span>فوت ہونے والا وارث</span><select onchange="MNUI.dead(' + i + ',this.value)"><option value="">— منتخب کریں —</option>' +
          opts.map(function (o) {
            return '<option value="' + o.id + '"' + (L.dead === o.id ? ' selected' : '') + '>' + esc(o.label) + ' — حصہ ' + o.units + '/' + prev.J + '</option>';
          }).join('') + '</select></div>';
        if (!prev) h += '<div class="warn">پہلے اوپر والے مسئلے کے ورثاء درست درج کریں۔</div>';
      }
      G.forEach(function (grp) {
        h += '<div style="margin-top:4px"><b>' + grp[0] + '</b></div>';
        grp[1].forEach(function (x) {
          h += '<div class="row"><span>' + x[1] + '</span>' + stepper(i, x[0]) + '</div>';
        });
      });
      if (i > 0) {
        var prev2 = res.steps[i - 1], list = prev2 ? prev2.aliveAfter.filter(function (o) { return o.id !== L.dead; }) : [], hs = headsOf(i);
        if (list.length && hs.length) {
          h += '<details style="margin-top:6px"><summary>ایک ہی شخص کا ملاپ (اختیاری)</summary>' +
            '<div class="sc">اگر اس مسئلے کا کوئی وارث وہی شخص ہے جو پہلے مسئلے میں بھی وارث تھا تو اسے یہاں جوڑ دیں، تاکہ اس کے حصے ایک ہی شخص میں جمع ہوں۔</div>' +
            hs.map(function (x) {
              return '<div class="row"><span>' + x.name + '</span><select onchange="MNUI.lk(' + i + ",'" + x.id + "',this.value)\"><option value=\"\">نہیں (الگ شخص)</option>" +
                list.map(function (o) { return '<option value="' + o.id + '"' + (L.link[x.id] === o.id ? ' selected' : '') + '>' + esc(o.label) + '</option>'; }).join('') +
                '</select></div>';
            }).join('') + '</details>';
        }
        h += '<button class="np" style="margin-top:6px" onclick="MNUI.rm(' + i + ')">یہ وفات (اور بعد کی وفات) ہٹائیں</button>';
      }
      h += '</div>';
    });
    document.getElementById('mnList').innerHTML = h;
    var canAdd = res && !res.err;
    document.getElementById('mnAdd').disabled = !canAdd;
    document.getElementById('mnOut').innerHTML = show ? out : '';
  }

  function msg(t) { document.getElementById('mnMsg').innerHTML = t ? '<div class="err">' + t + '</div>' : ''; }

  function run() {
    msg(''); show = false;
    var est = parseFloat(document.getElementById('mnEst').value);
    if (!(est >= 0)) return msg('مالِ ترکہ درست (صفر یا زائد) درج کریں۔');
    res = compute(levels);
    if (res.err) { out = '<div class="warn">⚠ ' + res.err + '</div>'; show = true; return draw(); }
    if (levels.length < 2) { out = '<div class="warn">مناسخہ کے لیے کم از کم ایک وارث کی وفات شامل کریں۔ اگر کوئی وارث فوت نہیں ہوا تو "حساب" والا باب استعمال کریں۔</div>'; show = true; return draw(); }
    var d = distribute(res, est), J = res.J, txt = ['مناسخہ | ترکہ: ' + money(d.P), 'جامعہ: ' + J], h = '';
    h += '<div class="card"><h2>مراحلِ حساب</h2>';
    res.steps.forEach(function (st) {
      var r = st.r, line = 'اصل مسئلہ <b>' + r.asl0 + '</b>';
      if (r.aw) line += ' ← عول <b>' + r.aw.to + '</b>';
      if (r.ra) line += ' ← رد <b>' + r.A1 + '</b>';
      if (r.corr !== (r.aw ? r.aw.to : r.ra ? r.A1 : r.asl0)) line += ' ← تصحیح <b>' + r.corr + '</b>';
      h += '<div class="sc"><b>مسئلہ ' + st.lv + '</b>' + (st.dead ? ' (مرحوم: ' + esc(st.dead) + ')' : ' (میت)') + '<br>' + line;
      if (st.lv > 1) {
        h += '<br>مرحوم کا حصہ <b>' + st.s + '</b> ، اس مسئلے کی تصحیح <b>' + r.corr + '</b> ← نسبت: <b>' + st.kind + '</b>' +
          (st.kind === 'توافق' ? ' (مشترک عدد ' + st.g + ')' : '') +
          '<br>پہلے مسئلے کے باقی ورثاء کا ضرب <b>' + st.f1 + '</b> ، اس مسئلے کے ورثاء کا ضرب <b>' + st.f2 + '</b> ← جامعہ <b>' + st.J + '</b>';
        if (st.s === 0n) h += '<br><span class="bad">مرحوم کو کوئی حصہ نہیں ملا۔</span>';
      }
      if (st.blocked.length) h += '<br>محروم: ' + st.blocked.map(function (b) { return N[b[0]]; }).join('، ');
      if (!st.ok) h += '<br><span class="bad">⚠ حصوں کا مجموعہ جامعہ کے برابر نہیں؛ نتیجہ قابلِ اعتماد نہیں۔</span>';
      h += '</div>';
      txt.push('مسئلہ ' + st.lv + (st.dead ? ' (مرحوم: ' + st.dead + ')' : '') + ' | تصحیح ' + r.corr + (st.lv > 1 ? ' | نسبت ' + st.kind + ' | ضرب ' + st.f1 + ' / ' + st.f2 : ''));
    });
    h += '</div>';
    var rows = '', tot = 0n;
    txt.push('ورثاء | نسبت | عددی حصے | فیصد | رقم');
    d.rows.forEach(function (p) {
      var nm = esc(p.label) + (p.lv > 1 ? ' [م' + p.lv + ']' : ''), rel = esc(relation(p)), q = d.q[p.id];
      tot += q;
      rows += '<tr><td>' + nm + '</td><td>' + rel + '</td><td>' + p.units + '</td><td>' + pct(p.units, J) + '</td><td>' + money(q) + '</td></tr>';
      txt.push(nm + ' | ' + relation(p) + ' | ' + p.units + ' | ' + pct(p.units, J) + ' | ' + money(q));
    });
    h += '<div class="card w"><table><tr><th>ورثاء</th><th>نسبت</th><th>عددی حصے</th><th>فیصد</th><th>رقم</th></tr>' + rows +
      '<tr><th>کل</th><th></th><th>' + J + '</th><th>100%</th><th>' + money(tot) + '</th></tr></table></div>';
    h += '<div class="card sc">' + (tot === d.P ? '<span class="ok">رقم کا مجموعہ ترکہ کے برابر ✓</span>' : '<span class="bad">رقم میں فرق!</span>') +
      (d.left > 0n ? ' &nbsp; (پیسوں کی ایڈجسٹمنٹ: ' + d.left + ' پیسہ)' : '') + '</div>';
    h += '<div class="warn">یہ نتیجہ مستند مفتی/ماہرِ فرائض کی تصدیق کے بغیر حتمی نہیں۔ علمی نگرانی: مفتی محمد سہیل البازی (منظوری کا دعویٰ نہیں)۔</div>';
    out = h; lastTxt = txt.join('\n'); show = true;
    draw();
    document.getElementById('mnOut').scrollIntoView({ behavior: 'smooth' });
  }

  function invalidate() { show = false; msg(''); }

  window.MNUI = {
    tg: function (i, k) { var c = levels[i].c; c[k] = c[k] ? 0 : 1; if (k === 'H' && c.H) c.W = 0; invalidate(); draw(); },
    ch: function (i, k, d) {
      var c = levels[i].c, v = (c[k] || 0) + d;
      if (v > MX[k]) { draw(); return msg('بیویوں کی تعداد چار سے زائد نہیں ہو سکتی۔'); }
      c[k] = Math.max(0, v); if (k === 'W' && c.W > 0) c.H = 0;
      invalidate(); draw();
    },
    dead: function (i, v) { levels[i].dead = v || null; levels[i].link = {}; invalidate(); draw(); },
    lk: function (i, id, v) { if (v) levels[i].link[id] = v; else delete levels[i].link[id]; invalidate(); draw(); },
    add: function () { levels.push({ dead: null, c: {}, link: {} }); invalidate(); draw(); },
    rm: function (i) { levels.splice(i); invalidate(); draw(); },
    run: run,
    clear: function () { levels = [{ dead: null, c: {}, link: {} }]; show = false; out = ''; lastTxt = ''; msg(''); draw(); },
    share: async function () {
      if (!lastTxt) return msg('پہلے حساب کریں۔');
      try { if (navigator.share) { await navigator.share({ title: 'مناسخہ', text: lastTxt }); return; } } catch (e) {}
      try { await navigator.clipboard.writeText(lastTxt); document.getElementById('mnMsg').innerHTML = '<div class="warn">متن کاپی ہو گیا۔</div>'; }
      catch (e) { msg('کاپی ممکن نہیں؛ نتیجہ دستی طور پر نقل کریں۔'); }
    },
    print: function () { try { window.print(); } catch (e) {} }
  };

  document.getElementById('t1').innerHTML =
    '<div class="card sc">مناسخہ: ترکہ تقسیم ہونے سے پہلے کوئی وارث فوت ہو جائے تو اس کا حصہ اس کے ورثاء میں منتقل ہوتا ہے۔ ' +
    'پہلے میت کے ورثاء درج کریں، پھر "وفات شامل کریں" سے فوت ہونے والے وارث اور اس کے ورثاء درج کریں۔ ایک سے زائد وفات بھی شامل ہو سکتی ہیں۔</div>' +
    '<div class="card np"><div class="row"><span>مالِ ترکہ (روپے، تجہیز و تکفین، قرض و وصیت کے بعد)</span><input id="mnEst" type="number" min="0" step="0.01" value="1000000" style="width:130px"></div></div>' +
    '<div id="mnList" class="np"></div><div id="mnMsg" class="np"></div>' +
    '<button id="mnAdd" class="np" style="width:100%;margin-bottom:6px" onclick="MNUI.add()">+ ایک اور وارث کی وفات شامل کریں</button>' +
    '<button class="pri np" onclick="MNUI.run()">مناسخہ کا حساب کریں</button>' +
    '<button class="np" style="margin:4px 0" onclick="MNUI.clear()">سب صاف کریں</button>' +
    '<div id="mnOut"></div>' +
    '<button class="np" onclick="MNUI.share()" style="width:100%;margin-bottom:6px">متن شیئر / کاپی کریں</button>' +
    '<button class="np" onclick="MNUI.print()" style="width:100%">پرنٹ / PDF محفوظ کریں</button>';
  draw();
})();
