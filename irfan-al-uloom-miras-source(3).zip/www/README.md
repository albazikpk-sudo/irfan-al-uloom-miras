# میراث کیلکولیٹر - انسٹال اور پلے اسٹور گائیڈ

## 1. ویب پر ہوسٹ کریں (لازمی، HTTPS)
اس فولڈر کی تمام فائلیں (index.html, manifest.webmanifest, sw.js, privacy.html, icons/, .well-known/) کسی HTTPS ہوسٹ پر اپلوڈ کریں، مثلاً Cloudflare Pages، Netlify یا GitHub Pages (مفت)۔
کھولنے کے بعد Chrome میں مینو ← "Install app / Add to Home screen" سے موبائل پر انسٹال ہو جائے گی (PWA)۔
privacy.html میں اپنا ای میل لکھیں۔

## 2. AAB بنائیں (Trusted Web Activity)
آسان راستہ: https://www.pwabuilder.com پر اپنی سائٹ کا لنک ڈالیں ← Package for stores ← Android ← Google Play۔
کمانڈ لائن راستہ (Node.js اور JDK درکار):
    npm i -g @bubblewrap/cli
    bubblewrap init --manifest https://YOURDOMAIN/manifest.webmanifest
    bubblewrap build
اس سے app-release-bundle.aab بنتا ہے۔ package id (مثلاً com.yourname.miras) اپنی مرضی سے رکھیں؛ بعد میں بدلا نہیں جا سکتا۔
keystore فائل اور پاس ورڈ محفوظ رکھیں۔

## 3. Digital Asset Links
Play Console ← App integrity ← App signing سے SHA-256 fingerprint لیں اور .well-known/assetlinks.json میں package_name اور fingerprint بدل کر دوبارہ اپلوڈ کریں۔ ورنہ ایپ میں اوپر براؤزر کی پٹی نظر آئے گی۔
فائل https://YOURDOMAIN/.well-known/assetlinks.json پر کھلنی چاہیے۔

## 4. Play Console
- ڈویلپر اکاؤنٹ بنائیں (ایک بار کی فیس)۔ نئے ذاتی اکاؤنٹس پر ٹیسٹنگ کی اضافی شرائط ہو سکتی ہیں؛ Play Console میں موجودہ شرائط دیکھ لیں۔
- نئی ایپ بنائیں ← AAB اپلوڈ کریں (پہلے Internal/Closed testing)۔
- Store listing: نام، مختصر و تفصیلی وضاحت، 512x512 آئیکن (icons/icon-512.png)، فیچر گرافک 1024x500، موبائل اسکرین شاٹس۔
- Privacy policy URL: https://YOURDOMAIN/privacy.html
- Data safety: کوئی ڈیٹا جمع/شیئر نہیں۔ Content rating سوالنامہ بھریں۔
- وضاحت میں لکھیں کہ نتیجہ مفتی کی تصدیق کے بغیر حتمی نہیں۔ "علمی منظوری" کا دعویٰ تب ہی کریں جب واقعی ہو چکی ہو۔

## 5. نوٹ
- اردو فونٹ گوگل فونٹس سے آتا ہے؛ پہلی بار انٹرنیٹ چاہیے، بعد میں کیش ہو جاتا ہے۔ مکمل آف لائن کے لیے فونٹ فائل خود ہوسٹ کریں۔
- ہر تبدیلی پر sw.js میں V کا نمبر بڑھائیں۔
